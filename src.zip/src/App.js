import React, { Component } from "react";

export class App extends Component {
  state = {};
  changeHandler = e => {
    this.setState({
      [e.target.name]: e.target.value
      // eslint-disable-next-line
    });
  };
  render() {
    return (
      <div className="container m-5 p-5 border border-1 border-info bg-dark text-white">
        <form
          className="form-group"
          onSubmit={e => {
            e.preventDefault();
            this.props.dispatchRegisterFlight(this.state);
          }}
        >
          Flight Number:
          <input
            type="text"
            onChange={this.changeHandler}
            className="form-control"
            name="fn"
          />
          Destination:{" "}
          <input
            type="text"
            onChange={this.changeHandler}
            className="form-control"
            name="des"
          />
          Departure:{" "}
          <input
            type="text"
            onChange={this.changeHandler}
            className="form-control"
            name="dep"
          />
          Date:{" "}
          <input
            type="text"
            onChange={this.changeHandler}
            className="form-control"
            name="date"
          />
          <input type="submit" value="Register" className="btn btn-primary" />
        </form>
      </div>
    );
  }
}

export default App;
